<?php
//include class model 
include "model/model.php";
	class controller {
		//variable public
	public $model;
	//inisisalisasi awal untuk class
	function __construct(){
		$this->model = new model ();
	}
	function view_login()
{ 
	include "view/login.php";
}
function index(){
	include "view/home.php";
}
// awals section buku
function index_buku(){
	$data = $this->model->select_all_buku();
	include "view/index_buku.php";
}
function view_insert_buku(){
	$data = $this->model->get_max_kd_buku();
	include "view/tambah_buku.php";
}
function view_edit_buku($id){
	$data = $this->model->select_id_buku($id);
	$row = $this->model->fetch($data);
	include "view/edit_buku.php";
}

function update_buku(){
	$kode = $_POST['kdb'];
	$nama = $_POST['nm_buku'];
	$pengarang = $_POST['pg_buku'];
	$penerbit = $_POST['pn_buku'];
	$tahun = $_POST['thn_buku']	;

	//upload foto
	$tipefile = $_FILES['cover']['type'];
	$lokasifile = $_FILES['cover']['tmp_name'];
	$ukuranfile = $_FILES['cover']['size'];
	$namafile = $_FILES['cover']['name'];
	$namafoto = $kode.".".end(explode(".",$namafile));
	$tempatfile = "cover_buku/$namafoto";
	
	move_uploaded_file($lokasifile, "$tempatfile");

	$update = $this->model->update_b($kode, $nama, $pengarang, $penerbit, $tahun, $tempatfile);
	header("location:index.php?idb=index_buku");
	
}
function delete_buku($id){
	$delete = $this->model->delete_b($id);
	header("location:index.php?idb=index_buku");
}
function insert_buku(){
	$kode = $_POST['kd_buku'];
	$nama = $_POST['nm_buku'];
	$pengarang = $_POST['pg_buku'];
	$penerbit = $_POST['pn_buku'];
	$tahun = $_POST['thn_buku']	;

	//upload foto
	$tipefile = $_FILES['cover']['type'];
	$lokasifile = $_FILES['cover']['tmp_name'];
	$ukuranfile = $_FILES['cover']['size'];
	$namafile = $_FILES['cover']['name'];
	$namafoto = $kode.".".end(explode(".",$namafile));
	$tempatfile = "cover_buku/$namafoto";
	
	move_uploaded_file($lokasifile, "$tempatfile");

	$insert = $this->model->insert_b($kode, $nama, $pengarang, $penerbit, $tahun, $tempatfile);
	header("location:index.php?idb=index_buku");
	}
	//akhir section buku
	
	//awal section anggota
	function index_anggota(){
		$data = $this->model->select_all_anggota();
		include "view/index_anggota.php";
	}
	function view_insert_anggota(){
		$data = $this->model->get_max_kd_anggota();
		include "view/tambah_anggota.php";
	}
	function view_edit_anggota($id){
		$data = $this->model->select_id_anggota($id);
		$row = $this->model->fetch($data);
		include "view/edit_anggota.php";
	}
	function insert_anggota(){
		$kode = $_POST['kd_anggota'];
		$nama = $_POST['nm_anggota'];
		$alamat = $_POST['alamat'];
		$tgl = $_POST['tgl_lahir'];
		$notel = $_POST['notel'];
		
		$insert = $this->model->insert_a($kode, $nama, $alamat, $tgl, $notel);
		header("location:index.php?ida=index_anggota");
	}
	function update_anggota(){
		$kode = $_POST['kda'];
		$nama = $_POST['nm_anggota'];
		$alamat = $_POST['alamat'];
		$tgl = $_POST['tgl_lahir'];
		$notel = $_POST['notel'];

		$update = $this->model->update_a($kode, $nama, $alamat, $tgl, $notel);
		header("location:index.php?ida=index_anggota");
	}
	function delete_anggota($id){
		$delete = $this->model->delete_a($id);
		header("location:index.php?ida=index_anggota");
	}
	//akhir section anggota
	
	//awal section pinjam
	function index_pinjam(){
	    $data = $this->model->select_all_pinjam();
	    include "view/index_pinjam.php";
	}
	function view_insert_pinjam(){
	    $data_a = $this->model->select_all_anggota();
	    $data_b = $this->model->select_all_buku();
	    $data_kd = $this->model->get_max_kd_pinjam();
	    include "view/tambah_pinjam.php";
	}
	function view_edit_pinjam($id){
	    $data_a = $this->model->select_all_anggota();
	    $data_b = $this->model->select_all_buku();
	    $data = $this->model->select_id_pinjam($id);
	    $row = $this->model->fetch($data);
	    include "view/edit_pinjam.php";
	}
	function insert_pinjam(){
	    $kode = $_POST['kd_pinjam'];
	    $kode_buku = $_POST['kd_buku'];
	    $kode_anggota = $_POST['kd_anggota'];
	    $tgl_pinjam = $_POST['tgl_pinjam'];
	    $tgl_kembali = $_POST['tgl_kembali'];
	    
	    $insert = $this->model->insert_p($kode, $kode_buku, $kode_anggota, $tgl_pinjam, $tgl_kembali);
	    header("location:index.php?idp=index_pinjam");
	}
	function update_pinjam(){
	    $kode = $_POST['kd_pinjam'];
	    $kode_buku = $_POST['kd_buku'];
	    $kode_anggota = $_POST['kd_anggota'];
	    $tgl_pinjam = $_POST['tgl_pinjam'];
	    $tgl_kembali = $_POST['tgl_kembali'];
	    
	    $update = $this->model->update_p($kode, $kode_buku, $kode_anggota, $tgl_pinjam, $tgl_kembali);
	    header("location:index.php?idp=index_pinjam");
	}
	function delete_pinjam($id){
	    $delete = $this->model->delete_p($id);
	    header("location:index.php?idp=index_pinjam");
	}
	//akhir section pinjam

	function __destruct(){
		
	}
	}
?>

