<?php
class model{
	public $connect;
	function __construct(){
		$this->connect = mysqli_connect("localhost","root","12345678","bukudb");
	}
	function execute($query){
		return mysqli_query($this->connect,$query);
	}
	
	// Buku functions
	function select_all_buku(){
		$query = "select * FROM buku";
		return $this->execute ($query);
	}
	function get_max_kd_buku(){
		$query = "select max(kode_buku)as kode from buku";
		return $this->execute($query);
	}
	function select_id_buku($id){
		$query = "select * FROM buku WHERE kode_buku = '$id'";
		return $this->execute($query);
	}
	function update_b ($kode, $nama, $pengarang, $penerbit, $tahun, $tempatfile){
		$query = "UPDATE buku SET nama_buku = '$nama', pengarang = '$pengarang', penerbit = '$penerbit', tahun_terbit = '$tahun', cover='$tempatfile' 
		WHERE kode_buku = '$kode'";
		return $this->execute($query);
	}
	function delete_b($id){
		$query = "DELETE FROM buku WHERE kode_buku = '$id'";
		return $this->execute($query);
	}
	function insert_b($kode,$nama,$pengarang,$penerbit,$tahun,$tempatfile){
		$query = "INSERT INTO buku (kode_buku,nama_buku,pengarang,penerbit,tahun_terbit,cover)
		values ('$kode','$nama','$pengarang','$penerbit','$tahun','$tempatfile')";
		return $this->execute($query);
	}
	
	// Anggota functions
	function select_all_anggota(){
		$query = "SELECT * FROM anggota";
		return $this->execute($query);
	}
	function get_max_kd_anggota(){
		$query = "SELECT MAX(kode_anggota) AS kode FROM anggota";
		return $this->execute($query);
	}
	function select_id_anggota($id){
		$query = "SELECT * FROM anggota WHERE kode_anggota = '$id'";
		return $this->execute($query);
	}
	function insert_a($kode,$nama,$alamat,$tgl,$notel){
		$query = "INSERT INTO anggota (kode_anggota,nama_anggota,alamat,tanggal_lahir,no_telp) VALUES ('$kode','$nama','$alamat','$tgl','$notel')";
		return $this->execute($query);
	}
	function update_a($kode,$nama,$alamat,$tgl,$notel){
		$query = "UPDATE anggota SET nama_anggota = '$nama', alamat = '$alamat', tanggal_lahir = '$tgl', no_telp = '$notel' WHERE kode_anggota = '$kode'";
		return $this->execute($query);
	}
	function delete_a($id){
		$query = "DELETE FROM anggota WHERE kode_anggota = '$id'";
		return $this->execute($query);
	}

	// Pinjam functions
	function select_all_pinjam(){
		// Join pinjam with buku and anggota to get names
		$query = "SELECT p.kode_pinjam, p.kode_buku, b.nama_buku, a.nama_anggota, p.tgl_pinjam, p.tgl_kembali
				  FROM pinjam p
				  JOIN buku b ON p.kode_buku = b.kode_buku
				  JOIN anggota a ON p.kode_anggota = a.kode_anggota";
		return $this->execute($query);
	}
	function get_max_kd_pinjam(){
		$query = "SELECT MAX(kode_pinjam) AS kode FROM pinjam";
		return $this->execute($query);
	}
	function select_id_pinjam($id){
		$query = "SELECT * FROM pinjam WHERE kode_pinjam = '$id'";
		return $this->execute($query);
	}
	function insert_p($kode,$kode_buku,$kode_anggota,$tgl_pinjam,$tgl_kembali){
		$query = "INSERT INTO pinjam (kode_pinjam,kode_buku,kode_anggota,tgl_pinjam,tgl_kembali)
				  VALUES ('$kode','$kode_buku','$kode_anggota','$tgl_pinjam','$tgl_kembali')";
		return $this->execute($query);
	}
	function update_p($kode,$kode_buku,$kode_anggota,$tgl_pinjam,$tgl_kembali){
		$query = "UPDATE pinjam SET kode_buku = '$kode_buku', kode_anggota = '$kode_anggota', tgl_pinjam = '$tgl_pinjam', tgl_kembali = '$tgl_kembali' WHERE kode_pinjam = '$kode'";
		return $this->execute($query);
	}
	function delete_p($id){
		$query = "DELETE FROM pinjam WHERE kode_pinjam = '$id'";
		return $this->execute($query);
	}

	function fetch($var){
		return mysqli_fetch_array($var);
	}
	function __destruct(){
	}
}
?>
