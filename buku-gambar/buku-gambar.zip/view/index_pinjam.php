<html>
<head>
	<title>MVC OOP PHP</title>
</head>
<body>
	<table border="1" cellpadding="5" cellspacing="0" align="center">
		<tr align="center">
			<td>Kode Pinjam</td>
			<td>Kode Buku</td>
			<td>Nama Buku</td>
			<td>Peminjam</td>
			<td>Tanggal Pinjam</td>
			<td>Tanggal Kembali</td>
			<td colspan="2">Aksi</td>
		</tr>
		<?php while($row = $this->model->fetch($data)){ ?>
			<tr>
			<td><?php echo $row['kode_pinjam'] ?></td>
			<td><?php echo $row['kode_buku']?></td>
			<td><?php echo $row['nama_buku']?></td>
			<td><?php echo $row['nama_anggota']?></td>
			<td><?php echo $row['tgl_pinjam']?></td>
			<td><?php echo $row['tgl_kembali']?></td>
			<td><a href='index.php?ep=<?php echo $row['kode_pinjam'] ?>'>Edit</a>
			<a href='index.php?dp=<?php echo $row['kode_pinjam'] ?>' onClick="return confirm('Hapus Data?')">Delete</a></td>
			</tr>
		<?php } ?>

	</table>
	<center><a href='index.php?ip=tambah_pinjam'>Tambah Data Pinjam</a> | <a href='index.php?home'>Homepage</a></center>
</body>
</html>