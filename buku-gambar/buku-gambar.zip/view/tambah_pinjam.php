<?php 
// pembuatan kode otomatis pinjam
$r = $this->model->fetch($data);
$kode=substr($r['kode'],3,8);
$tambah=$kode+1;
if($tambah<10){
	$id="PJ"."0000".$tambah;
}else{
	$id="PJ"."000".$tambah;
}
?>
<html>
<head>
	<title>MVC OOP PHP</title>
	<!-- jquery online -->
	<script
	src="https://code.jquery.com/jquery-1.12.4.min.js"
	integrity="sha256-ZosEbRLbNQzLpnKIkEdrPv7lOy9C27hHQ+Xp8a4MxAQ="
	crossorigin="anonymous"></script> 

</head>
<body>
	<fieldset>
		<center><b><h3>MVC OOP PHP Tambah Pinjam</h3></b></center>
		<form action="" method="POST">
			<div class="form-group" style="margin-bottom: 15px">
				<label for="kode">Kode Pinjam :</label>
				<input type="text" name="kd_pinjam" value="<?php echo $id ?>" readonly>
			</div>
			<div class="form-group" style="margin-bottom: 15px">
				<label for="pilih_b">Pilih Buku :</label>
				<select name="kd_buku" onChange="buku(this)">
					<option>-- Pilih Buku --</option>
					<?php while ($row = $this->model->fetch($data_b)) { ?>
						<option data-nama="<?php echo $row['nama_buku'] ?>" data-pengarang="<?php echo $row['pengarang'] ?>" data-penerbit="<?php echo $row['penerbit'] ?>" value="<?php echo $row['kode_buku'] ?>"><?php echo $row['kode_buku'] ?></option>
					<?php } ?>
				</select>
			</div>
			<div class="form-group" style="margin-bottom: 15px">
				<label for="nama">Nama Buku :</label>
				<input type="text" id="nm_buku" readonly>
			</div>
			<div class="form-group" style="margin-bottom: 15px">
				<label for="pengarang">Pengarang Buku :</label>
				<input type="text" id="pg_buku" readonly>
			</div>
			<div class="form-group" style="margin-bottom: 15px">
				<label for="penerbit">Penerbit Buku :</label>
				<input type="text" id="pn_buku" readonly>
			</div>
			<div class="form-group" style="margin-bottom: 15px">
				<label for="anggota">Anggota :</label>
				<select name="kd_anggota" onChange="anggota(this)">
					<option>-- Pilih Anggota --</option>
					<?php while ($r = $this->model->fetch($data_a)) { ?>
						<option data-nm="<?php echo $r['nama_anggota'] ?>" value="<?php echo $r['kode_anggota'] ?>"><?php echo $r['kode_anggota'] ?></option>
					<?php } ?>
				</select>
			</div>
			<div class="form-group" style="margin-bottom: 15px">
				<label for="nm_ag">Nama Anggota :</label>
				<input type="text" id="nm_ag" readonly>
			</div>
			<div class="form-group" style="margin-bottom: 15px">
				<label for="tgl_pinjam">Tanggal Pinjam :</label>
				<input type="date" name="tgl_pinjam">
			</div>
			<div class="form-group" style="margin-bottom: 15px">
				<label for="tgl_kembali">Tanggal Kembali :</label>
				<input type="date" name="tgl_kembali">
			</div>
			<input type="submit" name="submit"/> <a href="index.php?idp=index_pinjam">Kembali</a>
		</form>
	</fieldset>
</body>
</html>
<!-- script ini berfungsi saat pilih buku/anggota akan memunculkan detail nya -->
<script type="text/javascript">
	function buku(elem) {
		var nmb = $(elem).find("option:selected").attr("data-nama");
		var pg = $(elem).find("option:selected").attr("data-pengarang");
		var pn = $(elem).find("option:selected").attr("data-penerbit");
		document.getElementById("nm_buku").value = nmb;
		document.getElementById("pg_buku").value = pg;
		document.getElementById("pn_buku").value = pn;
	}
	function anggota(elem) {
		var nma = $(elem).find("option:selected").attr("data-nm");
		document.getElementById("nm_ag").value = nma;
	}
</script>
<?php
	if(isset($_POST['submit'])){ //jika button submit diklik maka panggil fungsi insert pada controller
		$main = new controller();
		$main->insert_pinjam();
	}
	?>